<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);


require_once APP_PATH.'aplicativo.entidad.php';
require_once APP_PATHS.'aplicativo.model.php';
*/
require_once("models/tmp_catalogo.entidad.php");
require_once("models/tmp_catalogo_model.php");

$cat = new Catalogo();
$model = new CatalogoModel();

require_once("views/catalogo_view.phtml");
?>

