<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);


require_once APP_PATH.'aplicativo.entidad.php';
require_once APP_PATHS.'aplicativo.model.php';
*/
require_once("models/aplicativo.entidad.php");
require_once("models/aplicativo_model.php");

// Logica
$apl = new Aplicativo();
$model = new AplicativoModel();

if(isset($_REQUEST['action']))
{
	switch($_REQUEST['action'])
	{
		case 'actualizar':
			$apl->__SET('idaplicativo',             $_REQUEST['idaplicativo']);
			$apl->__SET('codigo_aplicativo',        $_REQUEST['codigo_aplicativo']);
			$apl->__SET('nombre_aplicativo',        $_REQUEST['nombre_aplicativo']);
			$apl->__SET('estado_aplicativo',        $_REQUEST['estado_aplicativo']);


			$model->Actualizar($apl);
			header('Location: index.php');
			break;

		case 'registrar':
			$apl->__SET('codigo_aplicativo',        $_REQUEST['codigo_aplicativo']);
			$apl->__SET('nombre_aplicativo',        $_REQUEST['nombre_aplicativo']);
			$apl->__SET('estado_aplicativo',        $_REQUEST['estado_aplicativo']);


			$model->Registrar($apl);
			header('Location: index.php');
			break;

		case 'eliminar':
			$model->Eliminar($_REQUEST['idaplicativo']);
			header('Location: index.php');
			break;

		case 'editar':
			$apl= $model->Obtener($_REQUEST['idaplicativo']);
			//$apl= $model->Porcentaje($_REQUEST['idaplicativo']);
			
			break;
	}
}
require_once("views/ejecucion_view.phtml");
?>