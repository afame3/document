<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);


require_once APP_PATH.'aplicativo.entidad.php';
require_once APP_PATHS.'aplicativo.model.php';
*/
require_once("models/usuario.entidad.php");
require_once("models/usuario_model.php");

$usu = new Usuario();
$model = new UsuarioModel();

require_once("models/proveedor.entidad.php");
require_once("models/proveedor_model.php");

$pro = new Proveedor();
$emp = new ProveedorModel();

if(isset($_REQUEST['action']))
{
	switch($_REQUEST['action'])
	{
		case 'actualizar':
			$usu->__SET('idusuario',             $_REQUEST['idusuario']);
			$usu->__SET('matricula',        $_REQUEST['matricula']);
			$usu->__SET('nombre_usuario',        $_REQUEST['nombre_usuario']);
			$usu->__SET('clave',        $_REQUEST['clave']);
			$usu->__SET('correo',        $_REQUEST['correo']);
			$usu->__SET('estado',        $_REQUEST['estado']);
			$usu->__SET('fecha_alta',        $_REQUEST['fecha_alta']);
			$usu->__SET('idproveedor',        $_REQUEST['idproveedor']);

			$model->Actualizar($usu);
			header('Location: index.php');
			break;

		case 'registrar':
			$usu->__SET('matricula',        $_REQUEST['matricula']);
			$usu->__SET('nombre_usuario',        $_REQUEST['nombre_usuario']);
			$usu->__SET('clave',        $_REQUEST['clave']);
			$usu->__SET('correo',        $_REQUEST['correo']);
			$usu->__SET('estado',        $_REQUEST['estado']);
			$usu->__SET('fecha_alta',        $_REQUEST['fecha_alta']);
			$usu->__SET('proveedor',        $_REQUEST['proveedor']);


			$model->Registrar($usu);
			header('Location: home.php');
			break;

		case 'eliminar':
			$model->Eliminar($_REQUEST['idusuario']);
			header('Location: index.php');
			break;

		case 'editar':
			$apl= $model->Obtener($_REQUEST['idusuario']);
			
			break;
	}
}
require_once("views/new_usuario_view.phtml");
?>