<?php

class Cotizacion
{
	private $idcotizacion;
	private $numero_cotizacion;
	private $estado_cotizacion;
	private $empresa_idempresa;
	private $empleado_idempleado;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}