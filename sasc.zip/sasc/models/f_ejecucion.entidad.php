<?php

class Ejecucion
{
	private $nSteCodigo;
	private $nEjeCodigo;
	private $dEjeIni;
	private $dEjeFin;
	private $cEjeResultado;
	private $nCasCosdigo;
	private $nPetCodigo;
	private $cEstadoEjecucion;
	private $cNombrePc;
	private $nOrden;
	private $cCodResultado;
	private $dEjeFechaEjecucion;
	private $cEjeNombreQC;
	private $nEjeActivo;
	private $cAmbCodigo;
	private $cTecCodigo;
	
	private $cAppDescripcion;
		
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}