<?php

class Schedule
{
	private $executar;
	private $executado;
	private $data_exec;
	private $hora_exec;
	private $script;
	private $nombre_version;
	private $corrida;
	private $casos_ejecutar;
	private $limpia_casos;
	private $sistema;
	private $ambiente;
	private $maquina;
	private $aplicativo;
	private $exec_com_erro;
	private $tester_responsable;
		
	private $cAppDescripcion;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}