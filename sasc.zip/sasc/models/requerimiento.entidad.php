<?php

class Requerimiento
{
	private $idrequerimiento;
	private $sol_negocio;
	private $sol_tecnico;
	private $nombre_requerimiento;
	private $fecha_inicio_planificado;
	private $fecha_fin_planificado;
	private $fecha_inicio_construccion;
	private $fecha_fin_construccion;
	private $tipo_construccion;
	private $idaplicativo;
	private $idestado;
	private $idestado_cq;
	private $idproveedor;
	private $horas_construccion;
	private $indicador;
	
	private $aplicativo;
	private $estado;
	private $estado_cq;
	private $proveedor;
	
	
							
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}