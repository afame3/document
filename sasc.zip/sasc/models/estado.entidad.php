<?php

class Estado
{
	private $idestado;
	private $estado;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}