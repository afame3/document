<?php

class CotizacionModel
{

private $pdo;

	public function __CONSTRUCT()
	{
		try
		{
      		require_once("db/db.php");
			$this->pdo=Conectar::conexion();
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{

		try
		{
			$result = array();

			//$stm = $this->pdo->prepare("SELECT * FROM aplicativo where estado_aplicativo=1");
			
			$stm = $this->pdo->prepare("select c.idcotizacion,c.numero_cotizacion,emp.razon_social,em.nombre_empleado,c.estado_cotizacion from cotizacion c
inner join empresa emp on c.empresa_idempresa=emp.idempresa
inner join empleado em on c.empleado_idempleado=em.idempleado");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$cot = new Cotizacion();

				$cot->__SET('idcotizacion', $r->idcotizacion);
				$cot->__SET('numero_cotizacion', $r->numero_cotizacion);
				$cot->__SET('razon_social', $r->razon_social);
				$cot->__SET('nombre_empleado', $r->nombre_empleado);
				$cot->__SET('estado_cotizacion', $r->estado_cotizacion);
				
				$result[] = $cot;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Obtener($idcotizacion)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("SELECT * FROM cotizacion WHERE idcotizacion = ?");
			          

			$stm->execute(array($idcotizacion));
			$r = $stm->fetch(PDO::FETCH_OBJ);

			$cot = new Cotizacion();

			$cot->__SET('idcotizacion', $r->idcotizacion);
			$cot->__SET('numero_cotizacion', $r->numero_cotizacion);
			$cot->__SET('estado_cotizacion', $r->estado_cotizacion);
			$cot->__SET('empresa_idempresa', $r->empresa_idempresa);
			$cot->__SET('empleado_idempleado', $r->empleado_idempleado);
			
			return $cot;
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Eliminar($idcotizacion)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("DELETE FROM cotizacion WHERE idcotizacion = ?");			          

			$stm->execute(array($idcotizacion));
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Actualizar(Cotizacion $data)
	{
		try 
		{
			$sql = "UPDATE Cotizacion SET 
						numero_cotizacion          = ?, 
						estado_cotizacion        = ?,
						empresa_idempresa        = ?,
						empleado_idempleado            = ?
					WHERE idcotizacion = ?";

			$this->pdo->prepare($sql)
			     ->execute(
				array(
					$data->__GET('numero_cotizacion'), 
					$data->__GET('estado_cotizacion'), 
					$data->__GET('empresa_idempresa'),
					$data->__GET('empleado_idempleado'),
					$data->__GET('idcotizacion')
					)
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Registrar(Cotizacion $data)
	{
		try 
		{
		$sql = "INSERT INTO cotizacion (numero_cotizacion,estado_cotizacion,empresa_idempresa,empleado_idempleado) 
		        VALUES (?, ?, ?, ?)";

		$this->pdo->prepare($sql)
		     ->execute(
			array(
				$data->__GET('numero_cotizacion'), 
				$data->__GET('estado_cotizacion'), 
				$data->__GET('empresa_idempresa'),
				$data->__GET('empleado_idempleado')
				)
			);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
	/*
	public function Codigo()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("select codigo_aplicativo from aplicativo 
										WHERE estado_aplicativo = '1' ORDER BY codigo_aplicativo ASC ");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$cod = new Aplicativo();

				$cod->__SET('codigo_aplicativo', $r->codigo_aplicativo);

				$result[] = $cod;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
	*/
	
	/*
	public function Ida()
	{

		try
		{

			//$id=$_POST['codigo'];
			$id = isset($_POST['codigo']) ? $_POST['codigo'] : NULL;
			//$id=VPLU;
			$result = array();
//".$id."
			//$stm = $this->pdo->prepare("select idaplicativo from aplicativo 
				//						WHERE codigo_aplicativo = '$id' and estado_aplicativo = 1");
										
			$stm = $this->pdo->prepare("select ap.idaplicativo,ap.codigo_aplicativo, pa.porcentaje_regresion,pa.porcentaje_mejora from aplicativo ap
										inner join parametro pa on pa.idaplicativo=ap.idaplicativo
										where ap.codigo_aplicativo= '$id' and pa.estado = 1");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$ida = new Aplicativo();

				$ida->__SET('idaplicativo', $r->idaplicativo);
				$ida->__SET('codigo_aplicativo', $r->codigo_aplicativo);
				$ida->__SET('porcentaje_regresion', $r->porcentaje_regresion);
				$ida->__SET('porcentaje_mejora', $r->porcentaje_mejora);

				$result[] = $ida;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
	*/

}