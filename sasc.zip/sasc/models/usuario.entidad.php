<?php

class Usuario
{
	private $idusuario;
	private $matricula;
	private $nombre_usuario;
	private $clave;
	private $correo;
	private $estado;
	private $fecha_alta;
	private $idproveedor;
	
	private $proveedor;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}