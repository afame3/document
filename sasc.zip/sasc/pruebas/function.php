<?php
?>
<script type="text/javascript">

function dimePropiedades(){ 

   	var valor = document.formul.miSelect.options[indice].value 
return valor
}
</script>
