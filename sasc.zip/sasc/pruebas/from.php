<form action="action.php" method="post">
 <p>Su nombre: <input type="text" name="nombre" /></p>
 <p>Su edad: <input type="text" name="edad" /></p>
 <p> <select onchange="test()" name="aplicativo" >
                <option value="0" selected>MBBK</option>
				<option value="1" selected>PORT</option>
            </select></p>
 <p><input type="submit" /></p>
</form>