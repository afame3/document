-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.48


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema cultura_demo
--

CREATE DATABASE IF NOT EXISTS cultura_demo;
USE cultura_demo;

--
-- Definition of table `cotizacion`
--

DROP TABLE IF EXISTS `cotizacion`;
CREATE TABLE `cotizacion` (
  `idcotizacion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` varchar(45) NOT NULL,
  PRIMARY KEY (`idcotizacion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cotizacion`
--

/*!40000 ALTER TABLE `cotizacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `cotizacion` ENABLE KEYS */;


--
-- Definition of table `informacion_campo`
--

DROP TABLE IF EXISTS `informacion_campo`;
CREATE TABLE `informacion_campo` (
  `idinformacion_formato` int(4) NOT NULL AUTO_INCREMENT,
  `numero` decimal(10,0) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `sub_area` varchar(50) DEFAULT NULL,
  `puesto_trabajo` varchar(50) DEFAULT NULL,
  `riesgos` varchar(200) DEFAULT NULL,
  `puntos` float DEFAULT NULL,
  `numero_trabajadores` float DEFAULT NULL,
  `costo_unitario` decimal(10,0) DEFAULT NULL,
  `costo_parametro` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`idinformacion_formato`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informacion_campo`
--

/*!40000 ALTER TABLE `informacion_campo` DISABLE KEYS */;
INSERT INTO `informacion_campo` (`idinformacion_formato`,`numero`,`area`,`sub_area`,`puesto_trabajo`,`riesgos`,`puntos`,`numero_trabajadores`,`costo_unitario`,`costo_parametro`) VALUES 
 (1,'1','administracion','administracion',NULL,NULL,NULL,NULL,NULL,NULL),
 (2,'2',NULL,NULL,NULL,'Ruido por dosimetría',NULL,NULL,NULL,NULL),
 (3,'3',NULL,NULL,NULL,'Personal Administrativo',NULL,NULL,NULL,NULL),
 (4,'4',NULL,NULL,NULL,'Evaluación Ergnomica',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `informacion_campo` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
