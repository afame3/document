<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);


require_once APP_PATH.'aplicativo.entidad.php';
require_once APP_PATHS.'aplicativo.model.php';
*/
require_once("models/parametro.entidad.php");
require_once("models/parametro_model.php");

// Logica
$par = new Parametro();
$model = new ParametroModel();

if(isset($_REQUEST['action']))
{
	switch($_REQUEST['action'])
	{
		case 'actualizar':
			$par->__SET('idinformacion_formato',             $_REQUEST['idinformacion_formato']);
			$par->__SET('riesgos',        $_REQUEST['riesgos']);
			$par->__SET('numero_trabajadores',        $_REQUEST['numero_trabajadores']);
			$par->__SET('puntos',        $_REQUEST['puntos']);
			//$par->__SET('estado',        $_REQUEST['estado']);
			//$par->__SET('idaplicativo',        $_REQUEST['idaplicativo']);

			$model->Actualizar($par);
			header('Location: parametro.php');
			break;

		case 'registrar':
			$par->__SET('riesgos',        $_REQUEST['riesgos']);
			$par->__SET('numero_trabajadores',        $_REQUEST['numero_trabajadores']);
			$par->__SET('puntos',        $_REQUEST['puntos']);
			//$par->__SET('estado',        $_REQUEST['estado']);
			//$par->__SET('idaplicativo',        $_REQUEST['idaplicativo']);


			$model->Registrar($par);
			header('Location: parametro.php');
			break;

		case 'eliminar':
			$model->Eliminar($_REQUEST['idinformacion_formato']);
			header('Location: parametro.php');
			break;

		case 'editar':
			$par= $model->Obtener($_REQUEST['idinformacion_formato']);
			break;
	}
}
require_once("views/parametro_view.phtml");
?>