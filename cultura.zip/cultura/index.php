<html>
	<head>
		<title>.: INFORMACION DE CAMPO :.</title>
		<link rel="stylesheet" type="text/css" href="./css/bootstrap.min.css">
	</head>
	<body>
	<?php include "views/navbar.phtml"; ?>	
	<div class="container">
	<div class="row">
	<div class="col-md-12">
			<h2>INFORMACION DE CAMPO</h2>
			<p class="lead">.....</p>
			<p>...</p>
			<p>...</p>
			<ol>
				<li>...</li>
				<li>...</li>
				<li>...</li>
			</ol>
			<br>
			<ul type="none">
			<li><i class="glyphicon glyphicon-ok"></i> Aplicaci�n web para visualizar el costo y beneficio de la automatizaci�n</li>
			<li><i class="glyphicon glyphicon-ok"></i> Ideal para el seguimiento</li>
			<li><i class="glyphicon glyphicon-ok"></i> Versi�n compatible con Google Chrome</li>
			</ul>

	</div>
	</div>
	</div>
	</body>
</html>