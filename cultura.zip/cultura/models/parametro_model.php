<?php

class ParametroModel
{

private $pdo;

	public function __CONSTRUCT()
	{
		try
		{
      		require_once("db/db.php");
			$this->pdo=Conectar::conexion();
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("select idinformacion_formato,riesgos, numero_trabajadores,puntos from informacion_campo ");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$par = new Parametro();

				$par->__SET('idinformacion_formato', $r->idinformacion_formato);
				$par->__SET('riesgos', $r->riesgos);
				$par->__SET('numero_trabajadores', $r->numero_trabajadores);
				$par->__SET('puntos', $r->puntos);

				
				$result[] = $par;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Obtener($idinformacion_formato)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("SELECT idinformacion_formato,riesgos,numero_trabajadores,puntos FROM informacion_campo WHERE idinformacion_formato = ?");
			          

			$stm->execute(array($idinformacion_formato));
			$r = $stm->fetch(PDO::FETCH_OBJ);

			$par = new Parametro();

			$par->__SET('idinformacion_formato', $r->idinformacion_formato);
			$par->__SET('riesgos', $r->riesgos);
			$par->__SET('numero_trabajadores', $r->numero_trabajadores);
			$par->__SET('puntos', $r->puntos);
			//$par->__SET('porcentaje_regresion_manual', $r->porcentaje_regresion_manual);
			//$par->__SET('estado', $r->estado);
			//$par->__SET('idaplicativo', $r->idaplicativo);
			//$par->__SET('aplicativo', $r->aplicativo);
			
			return $par;
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Eliminar($idinformacion_formato)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("DELETE FROM informacion_campo WHERE idinformacion_formato = ?");			          

			$stm->execute(array($idinformacion_formato));
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Actualizar(Parametro $data)
	{
		try 
		{
			$sql = "UPDATE informacion_campo SET 
						riesgos          = ?, 
						numero_trabajadores        = ?,
						puntos            = ?

					WHERE idinformacion_formato = ?";

			$this->pdo->prepare($sql)
			     ->execute(
				array(
					$data->__GET('riesgos'), 
					$data->__GET('numero_trabajadores'), 
					$data->__GET('puntos')
					//$data->__GET('estado'),
					//$data->__GET('idaplicativo'),
					//$data->__GET('idparametro')
					)
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Registrar(Parametro $data)
	{
		try 
		{
		$sql = "INSERT INTO informacion_campo (riesgos,numero_trabajadores,puntos)
		        VALUES (?, ?, ?)";

		$this->pdo->prepare($sql)
		     ->execute(
			array(
				$data->__GET('riesgos'), 
				$data->__GET('numero_trabajadores'), 
				$data->__GET('puntos')
				//$data->__GET('estado'),
				//$data->__GET('idaplicativo')
				)
			);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
}