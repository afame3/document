<?php

class Parametro
{
	private $idinformacion_formato;
	private $numero;
	private $area;
	private $sub_area;
	private $puesto_trabajo;
	private $riesgos;
	private $puntos;
	private $numero_trabajadores;
	private $costo_unitario;
	private $costo_parametro;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}