-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 13-09-2019 a las 11:27:17
-- Versión del servidor: 5.6.41-84.1
-- Versión de PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `headsys1_cultura_demo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `informacion_campo`
--

CREATE TABLE `informacion_campo` (
  `idinformacion_formato` int(4) NOT NULL,
  `numero` int(4) DEFAULT NULL,
  `area` varchar(50) NOT NULL,
  `sub_area` varchar(50) NOT NULL,
  `puesto_trabajo` int(4) NOT NULL,
  `riesgos` varchar(50) NOT NULL,
  `puntos` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `informacion_campo`
--
ALTER TABLE `informacion_campo`
  ADD PRIMARY KEY (`idinformacion_formato`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `informacion_campo`
--
ALTER TABLE `informacion_campo`
  MODIFY `idinformacion_formato` int(4) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
