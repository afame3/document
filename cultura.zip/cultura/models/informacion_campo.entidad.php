<?php

class Informacion_Campo
{
	private $idinformacion_formato;
	private $numero;
	private $area;
	private $sub_area;
	private $puesto_trabajo;
	private $riesgos;
	private $puntos;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}