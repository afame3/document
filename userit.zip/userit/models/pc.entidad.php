<?php

class Pc
{
	private $idpc;
	private $hostname;
	private $ip;
	private $descripcion;
	private $estado;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}