<?php

class Estado_cq
{
	private $idestado_cq;
	private $estado_cq;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}