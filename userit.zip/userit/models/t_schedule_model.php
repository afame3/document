<?php

class ScheduleModel
{

private $pdo;

	public function __CONSTRUCT()
	{
		try
		{
      		require_once("db/t_db.php");
			$this->pdo=Conectar::conexion();
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{
		try
		{
			$id=$_GET["nAppCodigo"];
			$result = array();
//GETDATE()
			$stm = $this->pdo->prepare("select ap.cAppDescripcion,ej.cEjeNombreQC,ej.dEjeIni,ej.dEjeFin,ej.cCodResultado,ej.cEjeResultado from Ejecucion ej 
inner join CasoPrueba ca on ej.nCasCodigo=ca.nCasCodigo
inner join Modulo mo on mo.nModCodigo=ca.nModCodigo
inner join Aplicativo ap on ap.nAppCodigo=mo.nAppCodigo
where ap.nAppCodigo= ".$id." and ej.dEjeFechaEjecucion=CONVERT(VARCHAR(10), GETDATE(), 126) and cEstadoEjecucion='E'");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$eje = new Ejecucion();

				$eje->__SET('cAppDescripcion', $r->cAppDescripcion);
				$eje->__SET('cEjeNombreQC', $r->cEjeNombreQC);
				$eje->__SET('dEjeIni', $r->dEjeIni);
				$eje->__SET('dEjeFin', $r->dEjeFin);
				$eje->__SET('cCodResultado', $r->cCodResultado);
				$eje->__SET('cEjeResultado', $r->cEjeResultado);
				
				$result[] = $eje;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
/*
	public function Obtener($idaplicativo)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("SELECT * FROM aplicativo WHERE idaplicativo = ?");
			          

			$stm->execute(array($idaplicativo));
			$r = $stm->fetch(PDO::FETCH_OBJ);

			$apl = new Aplicativo();

			$apl->__SET('idaplicativo', $r->idaplicativo);
			$apl->__SET('codigo_aplicativo', $r->codigo_aplicativo);
			$apl->__SET('nombre_aplicativo', $r->nombre_aplicativo);
			$apl->__SET('estado_aplicativo', $r->estado_aplicativo);
			
			return $apl;
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Eliminar($idaplicativo)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("DELETE FROM aplicativo WHERE idaplicativo = ?");			          

			$stm->execute(array($idaplicativo));
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Actualizar(Aplicativo $data)
	{
		try 
		{
			$sql = "UPDATE aplicativo SET 
						codigo_aplicativo          = ?, 
						nombre_aplicativo        = ?,
						estado_aplicativo            = ?
					WHERE idaplicativo = ?";

			$this->pdo->prepare($sql)
			     ->execute(
				array(
					$data->__GET('codigo_aplicativo'), 
					$data->__GET('nombre_aplicativo'), 
					$data->__GET('estado_aplicativo'),
					$data->__GET('idaplicativo')
					)
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Registrar(Aplicativo $data)
	{
		try 
		{
		$sql = "INSERT INTO aplicativo (codigo_aplicativo,nombre_aplicativo,estado_aplicativo) 
		        VALUES (?, ?, ?)";

		$this->pdo->prepare($sql)
		     ->execute(
			array(
				$data->__GET('codigo_aplicativo'), 
				$data->__GET('nombre_aplicativo'), 
				$data->__GET('estado_aplicativo')
				)
			);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
	public function Codigo()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("select codigo_aplicativo from aplicativo 
										WHERE estado_aplicativo = '1' ORDER BY codigo_aplicativo ASC ");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$cod = new Aplicativo();

				$cod->__SET('codigo_aplicativo', $r->codigo_aplicativo);

				$result[] = $cod;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
	
	public function Ida()
	{

		try
		{

			//$id=$_POST['codigo'];
			$id = isset($_POST['codigo']) ? $_POST['codigo'] : NULL;
			//$id=VPLU;
			$result = array();
//".$id."
			//$stm = $this->pdo->prepare("select idaplicativo from aplicativo 
				//						WHERE codigo_aplicativo = '$id' and estado_aplicativo = 1");
										
			$stm = $this->pdo->prepare("select ap.idaplicativo, pa.porcentaje_regresion,pa.porcentaje_mejora from aplicativo ap
										inner join parametro pa on pa.idaplicativo=ap.idaplicativo
										where ap.codigo_aplicativo= '$id' and pa.estado = 1");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$ida = new Aplicativo();

				$ida->__SET('idaplicativo', $r->idaplicativo);
				$ida->__SET('porcentaje_regresion', $r->porcentaje_regresion);
				$ida->__SET('porcentaje_mejora', $r->porcentaje_mejora);

				$result[] = $ida;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
*/
}