<?php

class AplicativoModel
{

private $pdo;

	public function __CONSTRUCT()
	{
		try
		{
      		require_once("db/f_db.php");
			$this->pdo=Conectar::conexion();
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("SELECT * FROM aplicativo order by nAppCodigo asc");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$apl = new Aplicativo();

				$apl->__SET('nAppCodigo', $r->nAppCodigo);
				$apl->__SET('cAppDescripcion', $r->cAppDescripcion);

				$result[] = $apl;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Obtener($nAppCodigo)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("SELECT * FROM aplicativo WHERE nAppCodigo = ?");
			          

			$stm->execute(array($nAppCodigo));
			$r = $stm->fetch(PDO::FETCH_OBJ);

			$apl = new nAppCodigo();

			$apl->__SET('nAppCodigo', $r->nAppCodigo);
			$apl->__SET('cAppDescripcion', $r->cAppDescripcion);

			
			return $apl;
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Eliminar($nAppCodigo)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("DELETE FROM aplicativo WHERE nAppCodigo = ?");			          

			$stm->execute(array($nAppCodigo));
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Actualizar(Aplicativo $data)
	{
		try 
		{
			$sql = "UPDATE aplicativo SET 
						cAppDescripcion          = ?
					WHERE nAppCodigo = ?";

			$this->pdo->prepare($sql)
			     ->execute(
				array(
					$data->__GET('cAppDescripcion'), 
					$data->__GET('nAppCodigo')
					)
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Registrar(Aplicativo $data)
	{
		try 
		{
		$sql = "INSERT INTO aplicativo (cAppDescripcion) 
		        VALUES (?)";

		$this->pdo->prepare($sql)
		     ->execute(
			array(
				$data->__GET('cAppDescripcion')
				)
			);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
	public function Codigo()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("select codigo_aplicativo from aplicativo 
										WHERE estado_aplicativo = '1' ORDER BY codigo_aplicativo ASC ");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$cod = new Aplicativo();

				$cod->__SET('codigo_aplicativo', $r->codigo_aplicativo);

				$result[] = $cod;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
	
	public function Ida()
	{

		try
		{

			//$id=$_POST['codigo'];
			$id = isset($_POST['codigo']) ? $_POST['codigo'] : NULL;
			//$id=VPLU;
			$result = array();
//".$id."
			//$stm = $this->pdo->prepare("select idaplicativo from aplicativo 
				//						WHERE codigo_aplicativo = '$id' and estado_aplicativo = 1");
										
			$stm = $this->pdo->prepare("select ap.idaplicativo, pa.porcentaje_regresion,pa.porcentaje_mejora from aplicativo ap
										inner join parametro pa on pa.idaplicativo=ap.idaplicativo
										where ap.codigo_aplicativo= '$id' and pa.estado = 1");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$ida = new Aplicativo();

				$ida->__SET('idaplicativo', $r->idaplicativo);
				$ida->__SET('porcentaje_regresion', $r->porcentaje_regresion);
				$ida->__SET('porcentaje_mejora', $r->porcentaje_mejora);

				$result[] = $ida;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

}