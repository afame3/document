<?php

class Aplicativo
{
	private $nAppCodigo;
	private $cAppDescripcion;
	
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}