<?php

class Parametro
{
	private $idparametro;
	private $porcentaje_regresion;
	private $porcentaje_mejora;
	private $porcentaje_regresion_manual;
	private $estado;
	private $idaplicativo;
	
	private $aplicativo;
	
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}