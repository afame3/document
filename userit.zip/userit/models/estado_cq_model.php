<?php

class Estado_cqModel
{

private $pdo;

	public function __CONSTRUCT()
	{
		try
		{
      		require_once("db/db.php");
			$this->pdo=Conectar::conexion();
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("SELECT * FROM estado_cq");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$esq = new Estado_cq();

				$esq->__SET('idestado_cq', $r->idestado_cq);
				$esq->__SET('estado_cq', $r->estado_cq);
				
				$result[] = $esq;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
/*
	public function Obtener($idusuario)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("SELECT * FROM usuario WHERE idusuario = ?");
			          

			$stm->execute(array($idusuario));
			$r = $stm->fetch(PDO::FETCH_OBJ);

			$usu = new Aplicativo();

				$usu->__SET('idusuario', $r->idusuario);
				$usu->__SET('matricula', $r->matricula);
				$usu->__SET('nombre_usuario', $r->nombre_usuario);
				$usu->__SET('clave', $r->clave);
				$usu->__SET('correo', $r->correo);
				$usu->__SET('estado', $r->estado);
				$usu->__SET('fecha_alta', $r->fecha_alta);
				$usu->__SET('idproveedor', $r->idproveedor);
			
			return $usu;
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Eliminar($idusuario)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("DELETE FROM usuario WHERE idusuario = ?");			          

			$stm->execute(array($idusuario));
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Actualizar(Usuario $data)
	{
		try 
		{
			$sql = "UPDATE usuario SET 
						matricula          = ?, 
						nombre_usuario        = ?,
						clave        = ?,
						correo        = ?,
						estado        = ?,
						fecha_alta        = ?,
						idproveedor            = ?
					WHERE idusuario = ?";

			$this->pdo->prepare($sql)
			     ->execute(
				array(
					$data->__GET('matricula'), 
					$data->__GET('nombre_usuario'), 
					$data->__GET('clave'),
					$data->__GET('correo'),
					$data->__GET('estado'),
					$data->__GET('fecha_alta'),
					$data->__GET('idproveedor')
					)
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Registrar(Usuario $data)
	{
		try 
		{
			$fecha_alta=date('Y-m-d');
			$estado=1;		
			
		$sql = "INSERT INTO usuario (matricula,nombre_usuario,clave,correo,estado,fecha_alta,idproveedor) 
		        VALUES (?, ?, ?, ?, ?, ?, ? )";

		$this->pdo->prepare($sql)
		     ->execute(
			array(
					$data->__GET('matricula'), 
					$data->__GET('nombre_usuario'), 
					$data->__GET('clave'),
					$data->__GET('correo'),
					//$data->__GET('estado'),
					$estado,
					//$data->__GET('fecha_alta'),
					$fecha_alta,
					$data->__GET('idproveedor')
				)
			);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
	public function Matricula()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("select matricula from usuario 
										WHERE estado = '1' ORDER BY matricula ASC ");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$mat = new Usuario();

				$mat->__SET('matricula', $r->matricula);

				$result[] = $mat;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
	
	public function Idusuario()
	{

		try
		{
			//$id=$_POST['usuario'];
			$id = isset($_POST['usuario']) ? $_POST['usuario'] : NULL;
			$result = array();

			$stm = $this->pdo->prepare("select * from usuario 
										WHERE matricula= '$id' and estado=1");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$usu = new Usuario();

				$usu->__SET('idusuario', $r->idusuario);
				$usu->__SET('matricula', $r->matricula);
				$usu->__SET('nombre_usuario', $r->nombre_usuario);

				$result[] = $usu;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}
	
	public function Login()
	{
		try 
		{
			$matricula = isset($_POST['matricula']) ? $_POST['matricula'] : NULL;
			$clave = isset($_POST['clave']) ? $_POST['clave'] : NULL;
			
			$result = array();
			$stm = $this->pdo
			          ->prepare("select * from usuario where matricula= '$matricula' and clave= '$clave' ");
			          

			$stm->execute();
			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
					{
						$idusuario = new Usuario();

						$idusuario->__SET('idusuario', $r->idusuario);

						//$result[] = $usu;
						}	
						//return $result;
			
			if($idusuario==null){
				print "<script>alert(\"Acceso invalido.\");window.location='../login.php';</script>";
			}else{
				session_start();
				$_SESSION["idusuario"]=$idusuario;
				print "<script>window.location='../home.php';</script>";	
			}
			
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
	*/
}