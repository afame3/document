<?php

class FuncionalidadModel
{
public $id;
	public function __CONSTRUCT()
	{
		try
		{
      		require_once("db/db.php");
			$this->pdo=Conectar::conexion();
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{

		try
		{
			$id=$_GET["idaplicativo"];
			$result = array();

			//$stm = $this->pdo->prepare("SELECT * FROM funcionalidad2 where aplicativo2_idaplicativo = ".$id);
			$stm = $this->pdo->prepare("SELECT * FROM funcionalidad where idaplicativo = ".$id." and estado_funcionalidad = 1");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$fun = new Funcionalidad();

				$fun->__SET('idfuncionalidad', $r->idfuncionalidad);
				$fun->__SET('numero_funcionalidad', $r->numero_funcionalidad);
				$fun->__SET('modulo_funcionalidad', $r->modulo_funcionalidad);
				$fun->__SET('operacion_funcionalidad', $r->operacion_funcionalidad);
				$fun->__SET('script_funcionalidad', $r->script_funcionalidad);
				$fun->__SET('url_funcionalidad', $r->url_funcionalidad);
				$fun->__SET('estado_funcionalidad', $r->estado_funcionalidad);
				//$fun->__SET('ejecutar_funcionalidad', $r->ejecutar_funcionalidad);
				//$fun->__SET('aplicativo2_idaplicativo', $r->aplicativo2_idaplicativo);
				$fun->__SET('idaplicativo', $r->idaplicativo);
				
				$result[] = $fun;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Obtener($idaplicativo)
	{
		try 
		{
			//$stm = $this->pdo->prepare("SELECT * FROM funcionalidad2 WHERE aplicativo2_idaplicativo = ?");
			$stm = $this->pdo->prepare("SELECT * FROM funcionalidad WHERE idaplicativo = ?");
		          
			$stm->execute(array($idaplicativo));
			$r = $stm->fetch(PDO::FETCH_OBJ);

			$fun = new Funcionalidad();

			$fun->__SET('idfuncionalidad', $r->idfuncionalidad);
			$fun->__SET('numero_funcionalidad', $r->numero_funcionalidad);
			$fun->__SET('modulo_funcionalidad', $r->modulo_funcionalidad);
			$fun->__SET('operacion_funcionalidad', $r->operacion_funcionalidad);
			$fun->__SET('script_funcionalidad', $r->script_funcionalidad);
			$fun->__SET('url_funcionalidad', $r->url_funcionalidad);
			
			return $fun;
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

/*
	public function Eliminar($idaplicativo)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("DELETE FROM aplicativo2 WHERE idaplicativo = ?");			          

			$stm->execute(array($idaplicativo));
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Actualizar(Aplicativo $data)
	{
		try 
		{
			$sql = "UPDATE aplicativo2 SET 
						codigo_aplicativo          = ?, 
						nombre_aplicativo        = ?,
						estado_aplicativo            = ?
					WHERE idaplicativo = ?";

			$this->pdo->prepare($sql)
			     ->execute(
				array(
					$data->__GET('codigo_aplicativo'), 
					$data->__GET('nombre_aplicativo'), 
					$data->__GET('estado_aplicativo'),
					$data->__GET('idaplicativo')
					)
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Registrar(Aplicativo $data)
	{
		try 
		{
		$sql = "INSERT INTO aplicativo2 (codigo_aplicativo,nombre_aplicativo,estado_aplicativo) 
		        VALUES (?, ?, ?)";

		$this->pdo->prepare($sql)
		     ->execute(
			array(
				$data->__GET('codigo_aplicativo'), 
				$data->__GET('nombre_aplicativo'), 
				$data->__GET('estado_aplicativo')
				)
			);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
*/
}