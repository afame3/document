<?php

class Funcionalidad
{
	private $idfuncionalidad;
	private $numero_funcionalidad;
	private $modulo_funcionalidad;
	private $operacion_funcionalidad;
	private $script_funcionalidad;
	private $url_funcionalidad;
	private $estado_funcionalidad;
	//private $ejecutar_funcionalidad;
	//private $aplicativo2_idaplicativo;
	private $idaplicativo;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}