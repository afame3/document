<?php

class Calculadora
{
	private $idcalculadora;
	private $sol_tecnico;
	private $nombre_requerimiento;
	private $fecha_estimada;
	private $hora_estimada;
	private $regresion_total;
	private $porcentaje_regresion;
	private $porcentaje_mejora;
	private $porcentaje_regresion_manual;
	private $hora_estimada_final;
	private $estado;
	private $idaplicativo;
	private $idusuario;
	
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}