<?php

class SIS_TLC_TEL_OPMBCP_CP
{
	private $INDEX;
    private $ID_CASO;
	private $BROWSER;
	private $CMB_CUENTA;
	private $CMB_TFREC;
	private $CMB_CUENTA2;
	private $CMB_DENO;
	private $TXT_MONTO;
	private $TXT_REFERENCIA;
	private $BTN_CONTINUAR;
	private $BTN_REGRESAR;
	private $RDB_SELECCION;
	private $TXT_CORREO;
	private $TXT_MENSAJE;
	private $BTN_FIRAHORA;
	private $BTN_ENVFIRM;
	private $BTN_REGRESAR2;
	private $LNK_VERIFICAR;
	private $BTN_USERCERRAR;
	private $BTN_ACEPTARAF;
	private $BTN_REGRESARAF;
	private $TXT_CLAVE;
	private $NRO_CUENTA;
	private $BTN_ENVAHORA;
	private $BTN_ENVDESPUES;
	private $BTN_REGRESARCONFIR;
	private $LBL_CUENTA;
	private $LBL_CUENTA2;
	private $LBL_MONTO;
	private $LBL_MSJVALID;
	private $LBL_MSJVALIDFIR;
	private $KWD_VERIFICAR_EN_HOST;
	private $KWD_TIPO_CUENTA_ORIGEN;
	private $KWD_TIPO_CUENTA_DESTINO;
	private $CSP;
	private $TXT_CLAVE2;
	private $CMB_OTRACUENTA;
	private $RDB_SELECCIONT;
	private $TXT_NOMBRE;
	private $TXT_PANTALLA;
	private $TIEMPO_EJECUCION_QRY_ORG;
	private $TIEMPO_EJECUCION_QRY_DST;
	private $STEP_NAME;
	private $DESCRIPTION;
	private $DESIGN_STEPS;
	private $EXPECTED;
	private $SUBJECT;
	private $DESCRIPCION_ACIERTO;
	private $DESCRIPCION_ERROR;
	private $CASO_FELIZ;
	private $ESTADO_CASO;
	private $UTILIZADO;
	private $ACIERTO_ERROR;
	private $EJECUCION_AC_ERR;
	private $HORA;
	private $TIEMPO_EJECUCION_CASO;
		
	private $cAppDescripcion;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}