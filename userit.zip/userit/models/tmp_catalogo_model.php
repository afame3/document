<?php

class CatalogoModel
{

private $pdo;

	public function __CONSTRUCT()
	{
		try
		{
      		require_once("db/db.php");
			$this->pdo=Conectar::conexion();
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("select codigo_aplicativo,nombre_aplicativo,modulo_funcionalidad,operacion_funcionalidad from aplicativo a
										inner join funcionalidad f on f.idaplicativo=a.idaplicativo
										where a.estado_aplicativo=1 and f.estado_funcionalidad=1");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$cat= new Catalogo();

				$cat->__SET('codigo_aplicativo', $r->codigo_aplicativo);
				$cat->__SET('nombre_aplicativo', $r->nombre_aplicativo);
				$cat->__SET('modulo_funcionalidad', $r->modulo_funcionalidad);
				$cat->__SET('operacion_funcionalidad', $r->operacion_funcionalidad);
				
				$result[] = $cat;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	

}