<?php

class ParametroModel
{

private $pdo;

	public function __CONSTRUCT()
	{
		try
		{
      		require_once("db/db.php");
			$this->pdo=Conectar::conexion();
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{

		try
		{
			$result = array();

			$stm = $this->pdo->prepare("select idparametro,ap.codigo_aplicativo as aplicativo, pr.porcentaje_regresion,pr.porcentaje_mejora from parametro pr
inner join aplicativo ap on pr.idaplicativo=ap.idaplicativo
where pr.estado=1");
			$stm->execute();

			foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
			{
				$par = new Parametro();

				$par->__SET('idparametro', $r->idparametro);
				$par->__SET('aplicativo', $r->aplicativo);
				$par->__SET('porcentaje_regresion', $r->porcentaje_regresion);
				$par->__SET('porcentaje_mejora', $r->porcentaje_mejora);

				
				$result[] = $par;
			}

			return $result;
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Obtener($idparametro)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("SELECT pa.idparametro,pa.porcentaje_regresion,pa.porcentaje_mejora,pa.porcentaje_regresion_manual,pa.estado,pa.idaplicativo,ap.codigo_aplicativo as aplicativo FROM parametro pa
inner join aplicativo ap on pa.idaplicativo=ap.idaplicativo
WHERE pa.idparametro = ?");
			          

			$stm->execute(array($idparametro));
			$r = $stm->fetch(PDO::FETCH_OBJ);

			$par = new Parametro();

			$par->__SET('idparametro', $r->idparametro);
			$par->__SET('porcentaje_regresion', $r->porcentaje_regresion);
			$par->__SET('porcentaje_mejora', $r->porcentaje_mejora);
			$par->__SET('porcentaje_regresion_manual', $r->porcentaje_regresion_manual);
			$par->__SET('estado', $r->estado);
			$par->__SET('idaplicativo', $r->idaplicativo);
			$par->__SET('aplicativo', $r->aplicativo);
			
			return $par;
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Eliminar($idparametro)
	{
		try 
		{
			$stm = $this->pdo
			          ->prepare("DELETE FROM parametro WHERE idparametro = ?");			          

			$stm->execute(array($idparametro));
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Actualizar(Parametro $data)
	{
		try 
		{
			$sql = "UPDATE parametro SET 
						porcentaje_regresion          = ?, 
						porcentaje_mejora        = ?,
						porcentaje_regresion_manual            = ?,
						estado            = ?,
						idaplicativo            = ?
					WHERE idparametro = ?";

			$this->pdo->prepare($sql)
			     ->execute(
				array(
					$data->__GET('porcentaje_regresion'), 
					$data->__GET('porcentaje_mejora'), 
					$data->__GET('porcentaje_regresion_manual'),
					$data->__GET('estado'),
					$data->__GET('idaplicativo'),
					$data->__GET('idparametro')
					)
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Registrar(Parametro $data)
	{
		try 
		{
		$sql = "INSERT INTO parametro (porcentaje_regresion,porcentaje_mejora,porcentaje_regresion_manual,estado,idaplicativo)
		        VALUES (?, ?, ?, ?, ?)";

		$this->pdo->prepare($sql)
		     ->execute(
			array(
				$data->__GET('porcentaje_regresion'), 
				$data->__GET('porcentaje_mejora'), 
				$data->__GET('porcentaje_regresion_manual'),
				$data->__GET('estado'),
				$data->__GET('idaplicativo')
				)
			);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
}