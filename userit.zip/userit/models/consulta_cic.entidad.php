<?php

class Cic
{
	private $tipo_documento;
	private $numero_documento;

	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}