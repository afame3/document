<?php

class Catalogo
{
	private $idaplicativo;
	private $codigo_aplicativo;
	private $nombre_aplicativo;
	private $modulo_funcionalidad;
	private $operacion_funcionalidad;
	private $estado_funcionalidad;
	
	public function __GET($k){ return $this->$k; }
	public function __SET($k, $v){ return $this->$k = $v; }

}