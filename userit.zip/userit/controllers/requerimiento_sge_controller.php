<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);

require_once APP_PATH.'requerimiento.entidad.php';
require_once APP_PATHS.'requerimiento_model.php';
*/

require_once("models/requerimiento.entidad.php");
require_once("models/requerimiento_model.php");

// Logica
$req = new Requerimiento();
$model = new RequerimientoModel();

require_once("views/list_requerimiento_view.phtml");
?>