<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);


require_once APP_PATH.'aplicativo.entidad.php';
require_once APP_PATHS.'aplicativo.model.php';
*/
require_once("models/funcionalidad.entidad.php");
require_once("models/funcionalidad_model.php");

// Logica
$fun = new Funcionalidad();
$model = new FuncionalidadModel();

if(isset($_REQUEST['action']))
{
	switch($_REQUEST['action'])
	{
		case 'actualizar':
			$fun->__SET('idfuncionalidad',             	$_REQUEST['idfuncionalidad']);
			$fun->__SET('numero_funcionalidad',        	$_REQUEST['numero_funcionalidad']);
			$fun->__SET('nombre_funcionalidad',        	$_REQUEST['nombre_funcionalidad']);
			$fun->__SET('script_funcionalidad',         $_REQUEST['script_funcionalidad']);
			$fun->__SET('casos_funcionalidad',          $_REQUEST['casos_funcionalidad']);
			$fun->__SET('estado_funcionalidad',         $_REQUEST['estado_funcionalidad']);
			$fun->__SET('ejecutar_funcionalidad',       $_REQUEST['ejecutar_funcionalidad']);			
			//$fun->__SET('aplicativo2_idaplicativo',   $_REQUEST['aplicativo2_idaplicativo']);
			$fun->__SET('idaplicativo',            		$_REQUEST['idaplicativo']);
												


			$model->Actualizar($fun);
			header('Location: index.php');
			break;

		case 'registrar':
			$fun->__SET('numero_funcionalidad',        	$_REQUEST['numero_funcionalidad']);
			$fun->__SET('nombre_funcionalidad',        	$_REQUEST['nombre_funcionalidad']);
			$fun->__SET('script_funcionalidad',         $_REQUEST['script_funcionalidad']);
			$fun-->__SET('casos_funcionalidad',         $_REQUEST['casos_funcionalidad']);
			$fun->__SET('script_funcionalidad',         $_REQUEST['script_funcionalidad']);
			$fun->__SET('estado_funcionalidad',         $_REQUEST['estado_funcionalidad']);
			$fun->__SET('ejecutar_funcionalidad',       $_REQUEST['ejecutar_funcionalidad']);
			//$fun->__SET('aplicativo2_idaplicativo',   $_REQUEST['aplicativo2_idaplicativo']);
			$fun->__SET('idaplicativo',            		$_REQUEST['idaplicativo']);
			$model->Registrar($fun);
			header('Location: index.php');
			break;

		case 'eliminar':
			$model->Eliminar($_REQUEST['idfuncionalidad']);
			header('Location: index.php');
			break;

		case 'editar':
			$fun= $model->Obtener($_REQUEST['idfuncionalidad']);
			break;
	}
}

require_once("views/list_funcionalidad_view.phtml");
?>