<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);


require_once APP_PATH.'aplicativo.entidad.php';
require_once APP_PATHS.'aplicativo.model.php';
*/
require_once("models/consulta_cic.entidad.php");
require_once("models/consulta_cic_model.php");

$model = new CicModel();
$cic = new Cic();


$file ="xml/SOAP_CltDatosGralInqV23.xml";
$xml= simplexml_load_file($file);

	$doc=isset($_POST['numero_documento']) ? $_POST['numero_documento'] : NULL;
	//$doc=$_POST['numero_documento'];
$xmlIDCs = $xml->xpath("//*[starts-with(local-name(), 'IDC')]");

foreach ($xmlIDCs as $IDC) $IDC[0] = "    $doc   ";

$xml->asXML($file);
//echo $xml->asXML();

/* Logica
$apl = new Aplicativo();
$model = new AplicativoModel();

if(isset($_REQUEST['action']))
{
	switch($_REQUEST['action'])
	{
		case 'actualizar':
			$apl->__SET('idaplicativo',             $_REQUEST['idaplicativo']);
			$apl->__SET('codigo_aplicativo',        $_REQUEST['codigo_aplicativo']);
			$apl->__SET('nombre_aplicativo',        $_REQUEST['nombre_aplicativo']);
			$apl->__SET('estado_aplicativo',        $_REQUEST['estado_aplicativo']);


			$model->Actualizar($apl);
			header('Location: index.php');
			break;

		case 'registrar':
			$apl->__SET('codigo_aplicativo',        $_REQUEST['codigo_aplicativo']);
			$apl->__SET('nombre_aplicativo',        $_REQUEST['nombre_aplicativo']);
			$apl->__SET('estado_aplicativo',        $_REQUEST['estado_aplicativo']);


			$model->Registrar($apl);
			header('Location: index.php');
			break;

		case 'eliminar':
			$model->Eliminar($_REQUEST['idaplicativo']);
			header('Location: index.php');
			break;

		case 'editar':
			$apl= $model->Obtener($_REQUEST['idaplicativo']);
			//$apl= $model->Porcentaje($_REQUEST['idaplicativo']);
			
			break;
	}
}*/
require_once("views/consulta_cic_view.php");
?>