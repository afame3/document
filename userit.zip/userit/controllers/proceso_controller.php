<?php

require_once("views/proceso_view.phtml");
?>