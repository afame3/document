<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);
*/

require_once("models/usuario.entidad.php");
require_once("models/usuario_model.php");

require_once("models/aplicativo.entidad.php");
require_once("models/aplicativo_model.php");

$cod=new AplicativoModel();
$app= new Aplicativo();

// Logica
$mat=new UsuarioModel();
//$usu = new Usuario();


if(isset($_REQUEST['action']))
{
	switch($_REQUEST['action'])
	{
		
		case 'actualizar':
			$cal->__SET('idcalculadora',             $_REQUEST['idcalculadora']);
			$cal->__SET('sol_tecnico',        $_REQUEST['sol_tecnico']);
			$cal->__SET('nombre_requerimiento',        $_REQUEST['nombre_requerimiento']);
			$cal->__SET('fecha_estimada',        $_REQUEST['fecha_estimada']);
			$cal->__SET('hora_estimada',        $_REQUEST['hora_estimada']);
			$cal->__SET('regresion_total',        $_REQUEST['regresion_total']);
			$cal->__SET('porcentaje_regresion',        $_REQUEST['porcentaje_regresion']);
			$cal->__SET('porcentaje_mejora',        $_REQUEST['porcentaje_mejora']);
			$cal->__SET('porcentaje_regresion_manual',        $_REQUEST['porcentaje_regresion_manual']);
			$cal->__SET('hora_estimada_final',        $_REQUEST['hora_estimada_final']);
			$cal->__SET('estado',        $_REQUEST['estado']);
			$cal->__SET('idaplicativo',        $_REQUEST['idaplicativo']);
			$cal->__SET('idusuario',        $_REQUEST['idusuario']);


			$model->Actualizar($cal);
			header('Location: index.php');
			break;

		case 'registrar':
			$cal->__SET('sol_tecnico',        $_REQUEST['sol_tecnico']);
			$cal->__SET('nombre_requerimiento',        $_REQUEST['nombre_requerimiento']);
			$cal->__SET('fecha_estimada',        $_REQUEST['fecha_estimada']);
			$cal->__SET('hora_estimada',        $_REQUEST['hora_estimada']);
			$cal->__SET('regresion_total',        $_REQUEST['regresion_total']);
			$cal->__SET('porcentaje_regresion',        $_REQUEST['porcentaje_regresion']);
			$cal->__SET('porcentaje_mejora',        $_REQUEST['porcentaje_mejora']);
			$cal->__SET('porcentaje_regresion_manual',        $_REQUEST['porcentaje_regresion_manual']);
			$cal->__SET('hora_estimada_final',        $_REQUEST['hora_estimada_final']);
			$cal->__SET('estado',        $_REQUEST['estado']);
			$cal->__SET('idaplicativo',        $_REQUEST['idaplicativo']);
			$cal->__SET('idusuario',        $_REQUEST['idusuario']);


			$model->Registrar($cal);
			header('Location: estimacion.php');
			break;

		case 'eliminar':
			$model->Eliminar($_REQUEST['idcalculadora']);
			header('Location: index.php');
			break;

		case 'editar':
			$cal= $model->Obtener($_REQUEST['idcalculadora']);
			break;
	}
}

require_once("views/select_aplicacion_usuario_view.phtml");
?>