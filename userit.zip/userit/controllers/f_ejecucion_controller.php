<?php
/**
 * @category   elektro
 * @package    hav
 * @subpackage controllers
 * @copyright  copyright (c) 2017 equipo herramientas, automatización y virtualización
 * @license    
 * @link       http://qtctsqlc01/hav/
 * @since      
 * @version    Release: 1.0.1
 * @author     Aldo Manosalva E. <amanosalva@bcp.com.pe>
 */

/*
define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);

require_once APP_PATH.'pc.entidad.php';
require_once APP_PATHS.'pc.model.php';
*/

{
	switch(isset($_POST['codigo']) ? $_POST['codigo'] : NULL)
	{
		case 'Teller':
			require_once("models/f_ejecucion.entidad.php");
			require_once("models/f_ejecucion_model.php");
			
			//require_once APP_PATH.'pc.entidad.php';
			//require_once APP_PATHS.'pc.model.php';
			
			$eje = new Ejecucion();
			$model = new EjecucionModel();
			
			require_once("views/list_ejecucion_view.phtml");
			break;
			
		case 'Telecredito':
			require_once("models/t_SIS_TLC_TEL_OPMBCP_CP.entidad.php");
			require_once("models/t_SIS_TLC_TEL_OPMBCP_CP_model.php");

			$OCP = new SIS_TLC_TEL_OPMBCP_CP();
			$model = new SIS_TLC_TEL_OPMBCP_CP_Model();
			require_once("views/SIS_TLC_TEL_OPMBCP_CP_view.phtml");
			break;
			
		case 'PORTAL':
			require_once("models/NAME.entidad.php");
			require_once("models/NAME_model.php");

			$OCP = new SIS_TLC_TEL_OPMBCP_CP();
			$model = new SIS_TLC_TEL_OPMBCP_CP_Model();
			require_once("views/NAME.phtml");
			break;
	}
}

?>