<?php

/*define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', realpath(dirname(__FILE__)) . DS);
define('APP_PATH', BASE_PATH . 'controllers' . DS);
define('APP_PATHS', BASE_PATH . 'models' . DS);


require_once APP_PATH.'aplicativo.entidad.php';
require_once APP_PATHS.'aplicativo.model.php';
*/
require_once("models/parametro.entidad.php");
require_once("models/parametro_model.php");

// Logica
$par = new Parametro();
$model = new ParametroModel();

if(isset($_REQUEST['action']))
{
	switch($_REQUEST['action'])
	{
		case 'actualizar':
			$par->__SET('idparametro',             $_REQUEST['idparametro']);
			$par->__SET('porcentaje_regresion',        $_REQUEST['porcentaje_regresion']);
			$par->__SET('porcentaje_mejora',        $_REQUEST['porcentaje_mejora']);
			$par->__SET('porcentaje_regresion_manual',        $_REQUEST['porcentaje_regresion_manual']);
			$par->__SET('estado',        $_REQUEST['estado']);
			$par->__SET('idaplicativo',        $_REQUEST['idaplicativo']);

			$model->Actualizar($par);
			header('Location: parametro.php');
			break;

		case 'registrar':
			$par->__SET('porcentaje_regresion',        $_REQUEST['porcentaje_regresion']);
			$par->__SET('porcentaje_mejora',        $_REQUEST['porcentaje_mejora']);
			$par->__SET('porcentaje_regresion_manual',        $_REQUEST['porcentaje_regresion_manual']);
			$par->__SET('estado',        $_REQUEST['estado']);
			$par->__SET('idaplicativo',        $_REQUEST['idaplicativo']);


			$model->Registrar($par);
			header('Location: parametro.php');
			break;

		case 'eliminar':
			$model->Eliminar($_REQUEST['idparametro']);
			header('Location: parametro.php');
			break;

		case 'editar':
			$par= $model->Obtener($_REQUEST['idparametro']);
			break;
	}
}
require_once("views/parametro_view.phtml");
?>